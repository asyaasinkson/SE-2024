package put.io.patterns.implement;

public interface SystemStateObserver {
    void update(SystemState state);
}
